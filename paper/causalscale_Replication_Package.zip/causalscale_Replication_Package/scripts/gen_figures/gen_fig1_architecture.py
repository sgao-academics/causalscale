# =============================================================================
# Fig 1: Architecture Diagram (Page 3, §3 Architecture and Design)
# 7 engines: ClusterAware, DAGMA, Causal Transformer, LowRankGNN,
#            MultiScale, MultiModal, Ensemble
# Automatic dimension-based selection, pre-trained backbones, distribution.
# =============================================================================
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches, os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(SCRIPT_DIR))
# For desktop usage, output to paper/figures; for replication package, output to PKG_ROOT/figures
OUT = os.path.join(PKG_ROOT, 'figures')
# Fallback for running from paper/scripts/gen_figures/ directly
os.makedirs(OUT, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

fig, ax = plt.subplots(figsize=(8.0, 5.0))
ax.set_xlim(0, 10.5)
ax.set_ylim(0, 7.5)
ax.axis('off')

# ── Color palette: gradient cool → warm ──
C = {
    'cluster':  '#27AE60',  # green: small-d, exact DAG
    'dagma':    '#2980B9',  # blue: best F1 at low-d
    'ct':       '#F39C12',  # orange: mid-d transition
    'lowrank':  '#E74C3C',  # red: genome-scale
    'mscale':   '#8E44AD',  # purple: hierarchical
    'mm':       '#16A085',  # teal: multi-view
    'ensemble': '#2C3E50',  # dark: consensus voting
    'pretrain': '#1A6FB5',  # darker blue for pre-trained section
}

# ────────────────────────────────────────────────────────────────
# 1. TITLE
# ────────────────────────────────────────────────────────────────
ax.text(5.25, 7.10, 'causalscale: Unified Causal Discovery Engine',
        ha='center', fontsize=14, fontweight='bold', color='#2C3E50')

# ────────────────────────────────────────────────────────────────
# 2. API SURFACE BAR
# ────────────────────────────────────────────────────────────────
r_api = patches.FancyBboxPatch(
    (0.8, 6.10), 8.9, 0.65, boxstyle='round,pad=0.08',
    facecolor='#2C3E50', alpha=0.10, edgecolor='#2C3E50', linewidth=1.5
)
ax.add_patch(r_api)
ax.text(5.25, 6.42,
        'pip install causalscale     \u2502     cs.CausalDiscovery(data).fit()     \u2502     model.summary()',
        ha='center', fontsize=9, fontweight='bold', color='#2C3E50')

# ────────────────────────────────────────────────────────────────
# 3. SEVEN ENGINES (single row, dimension-ordered)
# ────────────────────────────────────────────────────────────────
engines = [
    #  x_center   Name              Description lines                Color
    (0.85,  'ClusterAware',  'd \u2264 200\nNOTEARS\nExact DAG',        C['cluster']),
    (2.20,  'DAGMA',         'd \u2264 150\nLog-Det Acyclicity\nBest F\u2081',  C['dagma']),
    (3.55,  'Causal Trans.', '200 < d \u2264 500\nSelf-Attention\nDAG Penalty', C['ct']),
    (4.90,  'LowRankGNN',    'd > 500\nW = UV\u1d40\nGenome-Scale',         C['lowrank']),
    (6.25,  'MultiScale',    'd = 500\u20135000\nHierarchical\nMulti-Res.',   C['mscale']),
    (7.60,  'MultiModal',    'm \u2265 2 Modalities\nCross-Modal\nConsensus',  C['mm']),
    (8.95,  'Ensemble',      'Voting\n3 Engines\nConsensus',           C['ensemble']),
]

for x, name, desc, color in engines:
    box = patches.FancyBboxPatch(
        (x - 0.55, 3.85), 1.10, 1.50,
        boxstyle='round,pad=0.06',
        facecolor=color, alpha=0.10, edgecolor=color, linewidth=1.5
    )
    ax.add_patch(box)
    # Engine name (top of box)
    ax.text(x, 5.10, name, ha='center', fontsize=6.8, fontweight='bold', color=color)
    # Description (3 lines, middle of box)
    ax.text(x, 4.20, desc, ha='center', fontsize=6.2, color='#444444',
            va='center', linespacing=1.25)

# ────────────────────────────────────────────────────────────────
# 4. AUTO-SELECTION LABEL
# ────────────────────────────────────────────────────────────────
r_auto = patches.FancyBboxPatch(
    (2.2, 3.35), 6.1, 0.30, boxstyle='round,pad=0.05',
    facecolor='#ECF0F1', edgecolor='#BDC3C7', linewidth=1.0
)
ax.add_patch(r_auto)
ax.text(5.25, 3.50, 'Automatic Dimension-Based Engine Selection',
        ha='center', fontsize=8.5, color='#555555', fontstyle='italic')

# ────────────────────────────────────────────────────────────────
# 5. PRE-TRAINED MODELS (HuggingFace)
# ────────────────────────────────────────────────────────────────
r_pretrain = patches.FancyBboxPatch(
    (0.5, 1.85), 9.5, 1.15, boxstyle='round,pad=0.08',
    facecolor=C['pretrain'], alpha=0.06, edgecolor=C['pretrain'], linewidth=1.5
)
ax.add_patch(r_pretrain)
ax.text(5.25, 2.78, 'Pre-Trained Causal Graphs on HuggingFace Hub',
        ha='center', fontsize=9.5, fontweight='bold', color=C['pretrain'])
ax.text(5.25, 2.18,
        'DepMap 19,215 genes  \u00b7  TCGA Pan-Cancer (7,960 edges, 33 types)  \u00b7  model = cs.load_pretrained("depmap")',
        ha='center', fontsize=7.5, color='#555555')

# ────────────────────────────────────────────────────────────────
# 6. DISTRIBUTION CHANNELS
# ────────────────────────────────────────────────────────────────
items = [
    #  x      Name          Description      Color
    (1.35,  'PyPI',        'pip install',    '#3498DB'),
    (3.20,  'CLI',         '6 commands',     '#8E44AD'),
    (5.05,  'Jupyter',     '4 tutorials',    '#16A085'),
    (6.90,  'HuggingFace', 'Pre-trained',    '#F39C12'),
    (8.75,  'GitHub',      'MIT License',    '#2C3E50'),
]
for x, name, desc, color in items:
    box = patches.FancyBboxPatch(
        (x - 0.55, 0.25), 1.10, 1.18,
        boxstyle='round,pad=0.04',
        facecolor=color, alpha=0.10, edgecolor=color, linewidth=1.3
    )
    ax.add_patch(box)
    ax.text(x, 1.20, name, ha='center', fontsize=7.5, fontweight='bold', color=color)
    ax.text(x, 0.62, desc, ha='center', fontsize=6.5, color='#666666')

# ────────────────────────────────────────────────────────────────
# SAVE
# ────────────────────────────────────────────────────────────────
plt.tight_layout(pad=0.3)
for fmt, ext in [('pdf', '.pdf'), ('png', '.png')]:
    path = os.path.join(OUT, f'fig1_architecture{ext}')
    fig.savefig(path, dpi=300, bbox_inches='tight')
    kb = os.path.getsize(path) / 1024
    print(f'Fig1 saved: {path} ({kb:.0f} KB)')
plt.close()
