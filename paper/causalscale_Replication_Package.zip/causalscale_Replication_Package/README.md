# causalscale v3.2.0 -- Replication Package

**KDD 2027 Datasets & Benchmarks Track**

Paper: *causalscale: Scaling Differentiable Causal Discovery to Genome-Wide Resolution*
Author: Shuaidong Gao (ORCID: 0009-0004-5641-3581, Chongqing Institute of Foreign Studies)

---

## Quick Start (Reviewer Verification)

All paper claims can be verified against pre-computed results without running any experiments:

```bash
cd causalscale_Replication_Package
pip install -e .
python run_all.py --verify
```

This validates (a) the package imports correctly, (b) pre-computed results in `results/` match paper claims, and (c) gen_figure scripts can regenerate figures from pre-computed data. No GPU required. ~2 minutes.

## Structure

```
causalscale_Replication_Package/
  run_all.py              # One-click reproduction (--verify / --benchmark / --scaling)
  README.md               # This file
  requirements.txt        # Python dependencies
  setup.py                # Package installer (v3.2.0)
  causalscale/            # Package source (7 engines + PCMCI)
  scripts/                # Benchmark scripts
    gen_figures/           # Figure generation (Fig1-4)
  results/                # Pre-computed JSON results (paper ground truth)
  examples/               # Jupyter tutorials
  tests/                  # Unit tests
```

## Reproducing Paper Results

### Option A: Verify pre-computed results (recommended for first pass)

| Command | What it does | Time |
|:--|:--|:--|
| `python run_all.py --verify` | Validates JSON results + regenerates figures | ~2 min |
| `python scripts/gen_figures/gen_fig1_architecture.py` | Regenerate Fig 1 | ~5 s |
| `python scripts/gen_figures/gen_fig2_benchmark.py` | Regenerate Fig 2 | ~10 s |
| `python scripts/gen_figures/gen_fig3_arid1a_mtor.py` | Regenerate Fig 3 | ~15 s |
| `python scripts/gen_figures/gen_fig4_timing.py` | Regenerate Fig 4 | ~10 s |

All figures output to `figures/` in the package root.

### Option B: Regenerate experiments from scratch

Requires: NVIDIA GPU (>=8 GB VRAM) or CPU (slower). External data needed for DepMap/TCGA validation.

| Command | What it does | Time |
|:--|:--|:--|
| `python run_all.py --benchmark` | Synthetic ER + SF + DAGMA (d=30-150, 5 seeds) | ~15 min |
| `python run_all.py --scaling` | LowRankGNN rank sensitivity (d=500) | ~30 min |
| `python run_all.py` | Full reproduction (synthetic + scaling) | ~1-2 h |

To regenerate DepMap STRING/TRRUST validation (88.7% precision):
1. Download DepMap CRISPR data from https://depmap.org/ (24Q2 release)
2. Download STRING PPI from https://string-db.org/ (v12.0, human)
3. Download TRRUST from https://www.grnpedia.org/trrust/ (v2, human)
4. Place under `data/depmap/`, `data/validation/string_ppi_full.txt.gz`, `data/validation/trrust_human.tsv`
5. Run `python scripts/validate_depmap_f1.py`

To regenerate pan-cancer scan:
1. Download TCGA expression from https://xenabrowser.net/ (HiSeqV2, gene-level RSEM)
2. Place under `data/tcga/`
3. Run `python run_all.py --tcga`

## Key Claims with Expected Results

| Paper Claim | Expected | Verified in |
|:--|:--|:--|
| causalscale ClusterAware F1 @ d=30 | 0.646 (exceeds DAGMA 0.589) | `results/exp16_final_bench.json` |
| NOTEARS death-line @ d=150 | F1=0.000 | Table 1 |
| DAGMA F1=0.989 @ d=150 | Mean >= 0.95 | `results/dagma_benchmark.json` |
| LowRankGNN @ d=17,787 | 132,683 edges, 4.1 min | Paper Table 4 |
| STRING/TRRUST precision | 88.7% (574/647 edges) | `results/exp15_string_mapped_f1.json` |
| Spearman edges vs n | rho=-0.720 (p=2.3e-6) | `results/pan_cancer_ckpt.json` |
| Cross-cancer conservation | 40.4% (3,212/7,960 edges) | `results/pan_cancer_ckpt.json` |
| S&P 500 same-sector | 76% (19/25 edges) | `results/sp500_results.json` |

## Hardware / Environment

- **Used in paper**: NVIDIA RTX 5060 (8 GB VRAM), AMD Ryzen 9 8945HX, 32 GB RAM, Python 3.12, PyTorch 2.11, CUDA 12.8
- **Minimum for --verify**: Any CPU, Python >=3.10
- **Minimum for --benchmark**: 8 GB GPU recommended; CPU fallback works (slower)
- **OS**: Linux, macOS, Windows (tested on all three)

## Dependencies

```
torch>=2.1, numpy>=1.24, scipy>=1.10, scikit-learn>=1.2,
pandas>=1.5, matplotlib>=3.7, networkx>=3.0, tqdm>=4.65, dagma>=0.1
```

## License

MIT License. All pre-trained models and benchmark data are included under the same license.

## Contact

Shuaidong Gao, gaoshuaidong@stu.cqifs.edu.cn
